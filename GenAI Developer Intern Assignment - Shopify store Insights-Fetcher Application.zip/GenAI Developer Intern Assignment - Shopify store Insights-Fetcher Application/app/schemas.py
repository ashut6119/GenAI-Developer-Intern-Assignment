{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "d6c66745-7929-4ac8-b25d-4212afd1f660",
   "metadata": {},
   "outputs": [],
   "source": [
    "from pydantic import BaseModel\n",
    "from typing import List, Optional\n",
    "\n",
    "class BrandDataSchema(BaseModel):\n",
    "    url: str\n",
    "    name: Optional[str] = None\n",
    "    product_catalog: List[dict] = []\n",
    "    hero_products: List[dict] = []\n",
    "    privacy_policy: Optional[str] = None\n",
    "    refund_policy: Optional[str] = None\n",
    "    return_policy: Optional[str] = None\n",
    "    faqs: List[dict] = []\n",
    "    social_handles: List[str] = []\n",
    "    contact_details: List[str] = []\n",
    "    about_brand: Optional[str] = None\n",
    "    important_links: List[str] = []\n",
    "\n",
    "    class Config:\n",
    "        orm_mode = True\n",
    "\n",
    "from pydantic import BaseModel\n",
    "\n",
    "class BrandResponse(BaseModel):\n",
    "    name: str\n",
    "    description: str\n",
    "\n",
    "    model_config = {\n",
    "        \"from_attributes\": True\n",
    "    }\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "9c3c7552-296a-492e-97da-c0b91854fd82",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "4b71bb87-dd95-461a-ab96-212a3a2d6cb0",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "e5a5cf22-2e7e-46de-a10c-60893e191374",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "20aea61a-afbc-41e2-ad1d-417e6dc4e65d",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "e5e6b32c-7a20-4d9d-92cd-a0fd7f694e4f",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "6ea87cb7-9e10-46e0-8153-db047c89c1c8",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c4554dd8-0aa6-437b-b07f-4436fff408a0",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "7acbbbaa-d284-4ba8-b16c-62ab3318f6e4",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "e4242a66-f0cc-40ea-84de-8cd977e9838d",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "6c485551-765c-4472-8999-6007de33cf4d",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "47196895-d4d1-4822-87b5-b6417e8ad9f8",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "55b14444-151b-48b7-b2b8-c50b020632a1",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
