from sqlalchemy import Column, Integer, String, Text, JSON
from app. database import Base

class BrandData(Base):
    __tablename__ = "brands"

    id = Column(Integer, primary_key=True, index=True)
    url = Column(String(255), unique=True, nullable=False)
    name = Column(String(255))
    product_catalog = Column(JSON)
    hero_products = Column(JSON)
    privacy_policy = Column(Text)
    refund_policy = Column(Text)
    return_policy = Column(Text)
    faqs = Column(JSON)
    social_handles = Column(JSON)
    contact_details = Column(JSON)
    about_brand = Column(Text)
    important_links = Column(JSON)