import sys
import os

sys.path.append(os.path.abspath(".."))

from fastapi import FastAPI, HTTPException, Query
from app import scraper, schemas, models
from .database import SessionLocal, engine
from sqlalchemy.orm import Session

models.Base.metadata.create_all(bind=engine)
app = FastAPI()

@app.get("/fetch_brand_data", response_model=schemas.BrandDataSchema)
def fetch_brand_data(website_url: str):
    result = scraper.scrape_shopify_site(website_url)

    if "error" in result:
        raise HTTPException(status_code=result.get("code", 500), detail=result["error"])

    # Persist to DB
    db: Session = SessionLocal()
    brand = models.BrandData(**result)
    db.add(brand)
    db.commit()
    db.refresh(brand)
    db.close()