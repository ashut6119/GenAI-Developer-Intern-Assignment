{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "579d3fcf-7a30-4bdc-82d2-5302a76ae80b",
   "metadata": {},
   "outputs": [],
   "source": [
    "# This file makes 'app' a Python package.\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "92012580-bb32-4039-a948-31693e05819f",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "3d218fcd-08f5-42a5-a6ee-648cd3085edc",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2f9ba4d7-38d1-4962-9a01-68efed3f2fdf",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "d2b88f0e-577d-46c8-8953-54be7586c543",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "9af5b1e5-67bc-483f-88e5-812e502a0939",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "7ddac797-99df-4ad7-9882-72fd9c7f7ac2",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "7685b172-5b50-40c3-852f-28b1f66105db",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "b2bea02b-1cc2-48d5-a6cf-6b87ab06415f",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "3b1d60e8-54f6-4382-b017-8dfbfaa30bb2",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "ad81831d-47f7-44ec-8c0d-c19189dcd88f",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "8b193d90-4ce1-4afc-9522-ac8b4caa2fb8",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "42df0c25-df30-4717-ba55-e3a7e446af5d",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "cafe6749-324b-4243-9a5c-d9cad1c68f1b",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "1124de5b-fe15-4071-aa53-b132a4f90079",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2b52a82b-b979-4118-80ae-538facaa08b3",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
